import inquirer from 'inquirer';

async function shoppingExperience() {
  const fruits = ['apple', 'banana', 'orange'];
  const vegetables = ['carrot', 'potato', 'onion'];
  const groceries = ['bread', 'milk', 'eggs'];

  const fruitPrice = 0.5;
  const vegetablePrice = 0.3;
  const groceryPrice = 1.0;

  let fruitQuantity = 0;
  let vegetableQuantity = 0;
  let groceryQuantity = 0;

  let totalBill = 0;

  const { choice } = await inquirer.prompt([
    {
      type: 'list',
      name: 'choice',
      message: 'Do you want fruits or vegetables?',
      choices: ['fruits', 'vegetables'],
    },
  ]);

  if (choice === 'fruits') {
    console.log(`We have ${fruits.join(', ')} for $${fruitPrice} each.`);
    const { fruitInput } = await inquirer.prompt([
      {
        type: 'input',
        name: 'fruitInput',
        message: 'How many fruits do you want?',
      },
    ]);
    fruitQuantity = parseInt(fruitInput);
    totalBill = fruitPrice * fruitQuantity;
  } else if (choice === 'vegetables') {
    console.log(`We have ${vegetables.join(', ')} for $${vegetablePrice} each.`);
    const { vegetableInput } = await inquirer.prompt([
      {
        type: 'input',
        name: 'vegetableInput',
        message: 'How many vegetables do you want?',
      },
    ]);
    vegetableQuantity = parseInt(vegetableInput);
    totalBill = vegetablePrice * vegetableQuantity;
  } else {
    console.log('Invalid choice. Please enter fruits or vegetables.');
    return;
  }

  const { answer } = await inquirer.prompt([
    {
      type: 'list',
      name: 'answer',
      message: 'Do you want groceries?',
      choices: ['yes', 'no'],
    },
  ]);

  if (answer === 'yes') {
    console.log(`We have ${groceries.join(', ')} for $${groceryPrice} each.`);
    const { groceryInput } = await inquirer.prompt([
      {
        type: 'input',
        name: 'groceryInput',
        message: 'How many groceries do you want?',
      },
    ]);
    groceryQuantity = parseInt(groceryInput);
    totalBill += groceryPrice * groceryQuantity;
  } else if (answer === 'no') {
    console.log('You do not want groceries.');
  } else {
    console.log('Invalid answer. Please enter yes or no.');
  }

  console.log(`Your total bill is $${totalBill.toFixed(2)}`);

  const discountRate = 0.1;
  const discountThreshold = 10;
  let discountAmount = 0;
  let discountedTotal = 0;

  if (totalBill > discountThreshold) {
    discountAmount = totalBill * discountRate;
    discountedTotal = totalBill - discountAmount;
    console.log(`You get a discount of $${discountAmount.toFixed(2)}. Your discounted total is $${discountedTotal.toFixed(2)}`);
  } else if (totalBill === discountThreshold) {
    console.log(`You are eligible for a discount. Your total bill is $${totalBill.toFixed(2)}`);
  } else {
    console.log(`You are not eligible for a discount. Your total bill is $${totalBill.toFixed(2)}`);
  }

  const paymentMethods = ['cash', 'card', 'mobile'];
  let paymentMethod = '';

  console.log('Thank you for shopping with us. Please proceed to the checkout counter.');

  while (true) {
    const { paymentInput } = await inquirer.prompt([
      {
        type: 'list',
        name: 'paymentInput',
        message: `How would you like to pay? We accept ${paymentMethods.join(', ')}.`,
        choices: paymentMethods,
      },
    ]);

    if (paymentMethods.includes(paymentInput)) {
      paymentMethod = paymentInput;
      break;
    } else {
      console.log('Invalid payment method. Please try again.');
    }
  }

  console.log(`You have chosen to pay by ${paymentMethod}. Your payment has been processed. Thank you for shopping with us. Have a nice day!`);
}

// Run the shopping experience function
shoppingExperience();
