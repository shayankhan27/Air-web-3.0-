// Scenario 1 - Modify Array with Methods
// Initialize an array with some initial elements

// Declare an array named colors
let colors = ["red", "green", "blue"];

// Display the original array
console.log("The original array is: " + colors);

// Use the push method to add "yellow" and "pink" to the end of the array
colors.push("yellow", "pink");

// Display the modified array
console.log("The array after push is: " + colors);

// Use the pop method to remove the last element from the array
let popped = colors.pop();

// Display the modified array and the removed element
console.log("The array after pop is: " + colors);
console.log("The popped element is: " + popped);

// Use the shift method to remove the first element from the array
let shifted = colors.shift();

// Display the modified array and the removed element
console.log("The array after shift is: " + colors);
console.log("The shifted element is: " + shifted);

// Use the unshift method to add "white" and "black" to the beginning of the array
colors.unshift("white", "black");

// Display the modified array
console.log("The array after unshift is: " + colors);

// Scenario 2 - Subarray Creation
// Implement the use of splice and slice to create subarrays from the original array
// splice: Create a subarray by removing elements from the original array
// slice: Create a subarray without modifying the original array

// Declare an array named numbers with some initial elements
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// Display the original array
console.log("The original array is: " + numbers);

// Use the splice method to remove 3 elements from index 4 and store them in a new array named spliced
let spliced = numbers.splice(4, 3);

// Display the modified array and the new array
console.log("The array after splice is: " + numbers);
console.log("The spliced array is: " + spliced);

// Use the slice method to create a new array named sliced with elements from index 2 to 5 (excluding 5) without modifying the original array
let sliced = numbers.slice(2, 5);

// Display the original array and the new array
console.log("The array after slice is: " + numbers);
console.log("The sliced array is: " + sliced);
