// Step 1: Define the function named 'add'
function add(num1: number, num2: number): number {
    // Step 2: Calculate the sum of the two numbers
    const result: number = num1 + num2;
    // Step 3: Return the result
    return result;
}

//Test the function
const num1: number = 5;
const num2: number = 3;
const sumResult: number = add (num1, num2);
console.log(`The sum of ${num1} and ${num2} is: ${sumResult}`);
