// Step 1: Define the function named 'checkEvenOrOdd'
function checkEvenOrOdd(number: number): string {
    // Step 2: Check if the number is even or odd
    if (number % 2 === 0) {
        // Step 3: Return a string indicating the number is even
        return "Even";
    } else {
        // Step 4: Return a string indicating the number is odd
        return "Odd";
    }
}

const testNumber: number = 7;
const result: string = checkEvenOrOdd(testNumber);
console.log(`The number ${testNumber} is: ${result}`)