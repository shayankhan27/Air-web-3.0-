// Step 1: Define the function named 'reverseString'
function reverseString(inputString) {
    // Step 2: Use the split, reverse, and join methods to reverse the string
    var reversedString = inputString.split('').reverse().join('');
    // Step 3: Return the reversed string
    return reversedString;
}
// Step 4: Test the function
var originalString = "Hello, World!";
var reversedResult = reverseString(originalString);
console.log("The reversed string is: ".concat(reversedResult));
