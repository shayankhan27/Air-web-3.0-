// Step 1: Define the function named 'reverseString'
function reverseString(inputString: string): string {
    // Step 2: Use the split, reverse, and join methods to reverse the string
    const reversedString: string = inputString.split('').reverse().join('');
    // Step 3: Return the reversed string
    return reversedString;
}

// Step 4: Test the function
const originalString: string = "Hello, World!";
const reversedResult: string = reverseString(originalString);
console.log(`The reversed string is: ${reversedResult}`);
