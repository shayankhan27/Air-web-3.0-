// Step 1: Define the function named 'calculateArea'
function calculateArea(width: number, height: number): number {
    // Step 2: Calculate the area of the rectangle
    const area: number = width * height;
    // Step 3: Return the calculated area
    return area;
}

// Step 4: Test the function
const rectangleWidth: number = 5;
const rectangleHeight: number = 10;
const areaResult: number = calculateArea(rectangleWidth, rectangleHeight);
console.log(`The area of the rectangle is: ${areaResult}`);
