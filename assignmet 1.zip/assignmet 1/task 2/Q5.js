// Step 1: Define the function named 'convertCelsiusToFahrenheit'
function convertCelsiusToFahrenheit(celsius) {
    // Step 2: Perform the temperature conversion formula
    var fahrenheit = (celsius * 9 / 5) + 32;
    // Step 3: Return the converted temperature in Fahrenheit
    return fahrenheit;
}
// Step 4: Test the function
var celsiusTemperature = 25;
var fahrenheitResult = convertCelsiusToFahrenheit(celsiusTemperature);
console.log("".concat(celsiusTemperature, " degrees Celsius is equal to ").concat(fahrenheitResult, " degrees Fahrenheit"));
