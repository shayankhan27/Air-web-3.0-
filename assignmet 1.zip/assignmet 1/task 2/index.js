// Step 1: Define the function named 'add'
function add(num1, num2) {
    // Step 2: Calculate the sum of the two numbers
    var result = num1 + num2;
    // Step 3: Return the result
    return result;
}
// Step 4: Test the function
var num1 = 5;
var num2 = 3;
var sumResult = add(num1, num2);
console.log("The sum of ".concat(num1, " and ").concat(num2, " is: ").concat(sumResult));
