// Step 1: Define the function named 'convertCelsiusToFahrenheit'
function convertCelsiusToFahrenheit(celsius: number): number {
    // Step 2: Perform the temperature conversion formula
    const fahrenheit: number = (celsius * 9 / 5) + 32;
    // Step 3: Return the converted temperature in Fahrenheit
    return fahrenheit;
}

// Step 4: Test the function
const celsiusTemperature: number = 25;
const fahrenheitResult: number = convertCelsiusToFahrenheit(celsiusTemperature);
console.log(`${celsiusTemperature} degrees Celsius is equal to ${fahrenheitResult} degrees Fahrenheit`);
