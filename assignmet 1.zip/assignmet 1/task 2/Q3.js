// Step 1: Define the function named 'calculateArea'
function calculateArea(width, height) {
    // Step 2: Calculate the area of the rectangle
    var area = width * height;
    // Step 3: Return the calculated area
    return area;
}
// Step 4: Test the function
var rectangleWidth = 5;
var rectangleHeight = 10;
var areaResult = calculateArea(rectangleWidth, rectangleHeight);
console.log("The area of the rectangle is: ".concat(areaResult));
